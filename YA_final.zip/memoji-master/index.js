let emoji_div = document.getElementsByClassName("emoji");

function createNewGame () {
    let shuffle_emoji = shuffle(emoji);
    for (let i = 0; i < emoji_div.length; i++) {
        emoji_div[i].innerHTML = shuffle_emoji[i];
    };
    eventListners();
    seconds.innerHTML = "01:00";
    t = 60;
    correctCount = 0;
}

function toggleClass(event) {
    let card = event.currentTarget;
    toggleVisibility(card);
}

function toggleVisibility (elem) {
    if (elem.nextElementSibling) {
        elem.nextElementSibling.classList.add("visible")
    } else {
        elem.previousElementSibling.classList.add("visible");
    }
    elem.classList.remove("visible");
}

let tempFaces = [];

function lookingForCorrect() {
    let faces = document.querySelectorAll(".face.visible:not(.correct)");
    if (faces.length == 2 && faces[0].innerHTML === faces[1].innerHTML) {
            setClassCorrect(faces); 
    } else if (faces.length == 2) {
        for (let i = 1; i >= 0; i--) {
            setClassWrong(faces[i]); 
            tempFaces[i] = faces[i];
        }
    } else if (faces.length == 3) {
        for (let i = 1; i >= 0; i--) {
            removeClassWrong(tempFaces[i]);
        }
    }
}

let id;
let correctCount = 0;

function setClassCorrect(face) {
    for (let i = 1; i >= 0; i--) {
        face[i].removeEventListener("click", toggleClass);
        face[i].classList.add("correct");
        correctCount++;
        if (correctCount == 11) {
            displayPopup(0);
            clearInterval(id);
        }
    }
}

function setClassWrong (face) {
    face.removeEventListener("click", toggleClass);
    face.classList.add("wrong");
}

function removeClassWrong (face) {
    face.classList.remove("wrong");
    face.addEventListener("click", toggleClass);
    toggleVisibility(face);
}

function displayPopup (i) {
    let popup = document.getElementsByClassName("popup");
    popup[i].classList.add("visible");
    popup[0].parentNode.classList.add("visible");
}

function hidePopup () {
    turnAllBack();
    setTimeout(createNewGame, 150);
    let popup = document.querySelector(".popup.visible");
    popup.classList.remove("visible");
    popup.parentNode.classList.remove("visible");
}

function turnAllBack () {
    let visibleFaces = document.querySelectorAll(".face")
    for (let i = 0; i < visibleFaces.length; i++) {
        toggleVisibility(visibleFaces[i]);
        visibleFaces[i].classList.remove("correct");
        visibleFaces[i].classList.remove("wrong");
    }
}

function startTimer () {
    const time = setInterval(updateTimer, 1000);
    id = time;
    for (let i = 0; i < listner.length; i++) {
        listner[i].removeEventListener("click", startTimer);
    }
}

let t = 60;

function updateTimer () {
    t--;
    seconds.innerHTML = "00:"+ ("0"+ t).slice(-2);
    if (t == 0) {
        clearInterval(id);
        displayPopup(1);
    }
}

function shuffle(arr){
	let j, temp;
	for(let i = arr.length - 1; i > 0; i--){
		j = Math.floor(Math.random()*(i + 1));
		temp = arr[j];
		arr[j] = arr[i];
		arr[i] = temp;
	}
	return emoji;
}

const listner = document.getElementsByClassName("listner");

function eventListners () {
    for (let i = 0; i < listner.length; i++) {
        listner[i].addEventListener("click", toggleClass);
        listner[i].addEventListener("click", lookingForCorrect);
        listner[i].addEventListener("click", startTimer);
    }
}

const emoji = ["🦄", "🦄", "🐨", "🐨", "🐭", "🐭", "🐓", "🐓", "🐷", "🐷", "🐯", "🐯"];

const button = document.getElementsByTagName("button")
for (let i = 0; i < button.length; i++) {
    button[i].addEventListener("click", hidePopup);
}

const seconds = document.getElementById("seconds");

createNewGame();